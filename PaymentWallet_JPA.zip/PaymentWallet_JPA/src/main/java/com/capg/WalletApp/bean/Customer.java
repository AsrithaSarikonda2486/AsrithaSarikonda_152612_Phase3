package com.capg.WalletApp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "customer123")
public class Customer {

	@Id
	private String userName;
	private String firstName;
	private String gender;
	private String contact;
	private String email;
	private int age;
	private long aadharNo;
	private String password;
	private long accNo;
	private long aadhar_no;
	private String branch;
	private double amount;
	private String account_type;
	@Lob
	private String transactions;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(String userName, String firstName, String gender, String contact, String email, int age,
			long aadharNo, String password, long accNo, long aadhar_no, String branch, double amount,
			String account_type, String transactions) {
		super();
		this.userName = userName;
		this.firstName = firstName;
		this.gender = gender;
		this.contact = contact;
		this.email = email;
		this.age = age;
		this.aadharNo = aadharNo;
		this.password = password;
		this.accNo = accNo;
		this.aadhar_no = aadhar_no;
		this.branch = branch;
		this.amount = amount;
		this.account_type = account_type;
		this.transactions = transactions;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public long getAadhar_no() {
		return aadhar_no;
	}

	public void setAadhar_no(long aadhar_no) {
		this.aadhar_no = aadhar_no;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

}
